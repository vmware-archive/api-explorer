"""
Copyright (c) 2016,  VMware Inc., All Rights Reserved.

SPDX-License-Identifier : BSD-3-Clause-Clear

This file is open source software released under the terms of the
BSD 3-Clause license, https://opensource.org/licenses/BSD-3-Clause:

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
 may be used to endorse or promote products derived from this software without
 specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

###############################################################################

This file is a utility meant for assisting with configuring metadata related
to VMware API Explorer

"""
from __future__ import print_function
# --------------------------------------------------------------------
# standard python imports
import argparse
import re
import sys
import os
import shutil

try:
    from urllib.parse import urlparse   #python3
except ImportError:
    from urlparse import urlparse  #python2

import traceback
import json
import glob
from sys import exit

#FIXMEfrom sets import Set

# --------------------------------------------------------------------
# locally installed package imports to avoid requirement of pip installing the tool in order to use
import yaml
#from ruamel.yaml import YAML
# markdown2 copied from https://github.com/trentm/python-markdown2
import markdown2
#FIXMEimport pyraml.parser

# --------------------------------------------------------------------
# local utils and libraries
import apixutils
from api_uids import add_products_from_filename
from api_uids import get_api_uid_for_file_name
from api_uids import dynamically_loaded_filename_to_api_uid_dict

import vmware_apix_client.apis
#from vmware_apix_client.apis.apis_api import ApiClient
#from vmware_apix_client.apis.apis_api import ApisApi
from apixutils import stdout
from apixutils import stderr
from apixutils import eprint
from apixutils import safe_str
#from vmware_apix_client.models.api import Api
#from inspect import ArgSpec
#from vmware_apix_client.models.api import

# this code attempts to get the column size.  this will fail if this is not a tty, e.g. running
# in a script, which which case it defaults to some sane value.  At some point when this is migrated
# to Python 3.3+ , change to str(shutil.get_terminal_size().columns)
os.environ['COLUMNS'] = '100'
try:
    if sys.stdout.isatty():
        rows, columns = os.popen('stty size', 'r').read().split()
        os.environ['COLUMNS'] = columns
except:
    pass

apisSkipped = 0
apisDropped = 0
apisAdded = 0
apisMirrored = 0
url_to_local_path_dict = {}

# set of keywords that we do not want to bother putting in the search index
keywordsToIgnore = set(["of","the","and","as","a","in","is","to","for","an","are"])

def safestr(obj):
    if not obj:
        return "None"
    else:
        return str(obj)

class Object(object):
    '''
    A generic object that is friendly towards taking standard python object as a dict
    and dumping it out as nice looking json.  it means you can use any Python object
    that is derived from it as a JSON class and serialize it easily to a JSON string.
    '''
    def toJSON(self):
        return json.dumps(self, default=lambda o: o.__dict__,
            sort_keys=True, indent=4)

class objectview(object):
    def __init__(self, d):
        self.__dict__ = d


def _load_api_uid_mappings(args):
    '''
    load an uid mappings provided externally if applicable
    '''
    if args.file_name_to_api_uid_properties_file_path:
        if not os.path.isfile(args.file_name_to_api_uid_properties_file_path):
            stderr("ERROR: api_uid mappings file '" + args.file_name_to_api_uid_properties_file_path + " is not a valid file.")
            exit(1)

        stdout("Reading api_uid mappings from " + args.file_name_to_api_uid_properties_file_path)
        apixutils.load_properties_file(args.file_name_to_api_uid_properties_file_path,dict_to_fill=dynamically_loaded_filename_to_api_uid_dict)

def _download_file_or_cache(url, staging_dir):
    global url_to_local_path_dict
    if url in url_to_local_path_dict:
        return url_to_local_path_dict.get(url)
    local_filename = apixutils.download_file(url,dir=staging_dir)
    url_to_local_path_dict[url] = local_filename
    return local_filename

def online_resource_to_local_resource(online_resource, download, staging_dir, html_root_dir):
    '''
    convert an online resource to a local resource.  If it is possible, download the file
    to the local directory and convert the links
    '''
    local_resource = Object()
    local_resource.resource_type = online_resource.resource_type
    local_resource.name = online_resource.name
    local_resource.description = online_resource.description
    local_resource.web_url = online_resource.web_url
    if  download and is_downloadable_file(online_resource.web_url):
        resource_doc_filename = _download_file_or_cache(online_resource.web_url,staging_dir)
        relativeFilePath = os.path.relpath(resource_doc_filename, html_root_dir)
        local_resource.web_url = relativeFilePath

    local_resource.download_url = online_resource.download_url
    if  download and is_downloadable_file(online_resource.download_url):
        resource_doc_filename = _download_file_or_cache(online_resource.download_url,staging_dir)
        relativeFilePath = os.path.relpath(resource_doc_filename, html_root_dir)
        local_resource.download_url = relativeFilePath
    local_resource.categories = []
    for category in online_resource.categories:
        local_resource.categories.append(category)

    local_resource.tags = []
    for online_tag in online_resource.tags:
        local_tag = Object()
        local_tag.id = online_tag.id
        local_tag.name = online_tag.name
        local_tag.category = online_tag.category
        local_resource.tags.append(local_tag)

    return local_resource

def add_local_overview_resource(api, name, local_url):
    """
    Resources is a map of lists of objects.  For SDKs and
    docs those are lists of Resource objects.  We are going to add
    a single "overview" resource that is one object.
    """
    overview_resource = Object()
    overview_resource.resource_type = 'DOC'
    overview_resource.name = name
    overview_resource.web_url = local_url
    overview_resource.download_url = local_url
    overview_resource.categories = [];
    overview_resource.categories.append("API_OVERVIEW");

    api.resources.append(overview_resource)

def is_downloadable_file( url ):
    '''
    Right now we are simply going to allow downloading/mirroring of files that we know are stand alone.
    TODO: perhaps we could use the wget mirroring feature to handle this so that we could actually attempt to
    mirror any link? # wget -p --convert-links http://www.server.com/dir/page.html
    '''
    if not url:
        return False
    return url.endswith('.pdf') or url.endswith('.zip') or url.endswith(".tar.gz")  #TODO make this smarter.  we should support any single file extension really.

def add_api(args, outputJson, api):
    global apisAdded
    global apisDropped
    addit = True

    if args and args.checkduplicates:
        for currentApi in outputJson.apis:
            if isinstance(currentApi,dict):
                # the json library creates dict's for everything.  this is annoying because the other api objects are actual
                # python objects
                currentApi = objectview(currentApi)
            if currentApi.api_uid == api.api_uid:
                # uid matches, additionall check versions
                if not currentApi.version and not api.version:
                    stdout("    Skipping addition of API " + api.api_uid + " name='" + api.name + "' version='" + api.version + "', there is already a versionless instance.")
                    addit = False
                    break
                elif currentApi.version and api.version and currentApi.version == api.version:
                    stdout("    Dropping addition of API " + api.api_uid + " name='" + api.name + "' version='" + api.version + "', version already present.")
                    addit = False
                    break
                #stdout("    current: name='" + currentApi.name + "' version='" + currentApi.version + "'" )
                #stdout("   check  : name='" + api.name + "' version='" + api.version + "'" )

    if addit:
        apisAdded = apisAdded + 1
        outputJson.apis.append(api)
    else:
        apisDropped = apisDropped + 1


def download_swagger( swagger_url, output_dir, verbose ):
    '''
    Downloads a swagger file from the given URL into the specified output directory.
    After it does this, it analyzes the description text as markdown to extract any set
    of relative links from the markdown.  For every link, it attempts to resolve it to
    a file that it then downloads to the appropriate relative directory.
    '''
    files_downloaded = []

    stdout("Downloading Swagger URL " + swagger_url)

    swagger_filename = apixutils.download_file(swagger_url, output_dir, verbose)
    files_downloaded.append(swagger_filename)

    swagger_parsed_url =  urlparse(swagger_url)
    swagger_parent_url = os.path.dirname(swagger_url)

    stdout("    Analyzing swagger file " + swagger_filename)

    try:
        with open(swagger_filename) as swagger_file:
            if swagger_filename.endswith(".json"):
                json_data = json.load(swagger_file)
            else:
                json_data = yaml.load(swagger_file)

            description_markdown = json_data['info']['description']

            link_list = apixutils.extract_markdown_relative_links(description_markdown)

            for link in link_list:
                parsed_link = urlparse(link)
                full_url = None
                if not parsed_link.netloc:
                    #it is a relative link, build a full URL and download it.
                    if parsed_link.path.startswith('/'):
                        #case 1 the path starts with / in which case we append to the netloc from the swagger file
                        full_url = swagger_parsed_url.scheme + "://" + swagger_parsed_url.netloc + parsed_link.path
                    else:
                        #case 2: the path is relative.  in this case we need to get the parent folder of the swagger file and then append the
                        #path for the link.
                        full_url = os.path.dirname(swagger_url) + "/" + parsed_link.path
                else:
                    full_url = link  # it is already absolute

                relpath = os.path.relpath(full_url, swagger_parent_url)

                full_local_path = os.path.join(output_dir,relpath)
                full_local_path_dir = os.path.dirname(full_local_path)
                if not os.path.isdir(full_local_path_dir):
                    os.makedirs(full_local_path_dir)

                swagger_dep_filename = apixutils.download_file(full_url, full_local_path_dir, verbose)
                files_downloaded.append(swagger_dep_filename)


    except Exception as e:
        stdout("    warning: swagger json '%s' has no description" % (swagger_filename))

    return files_downloaded

def add_string_to_keyword_set( stringToAdd, keywordSet ):
    if not stringToAdd:
        return
    stringToAdd = stringToAdd.lower()

    # contractions such as don't get messed up from below.  just strip any ' chars
    stringToAdd = re.sub('[\']+', '',stringToAdd)

    # remove all characters that are not alpha numeric, changing them to be spaces, then
    # strip both sides
    stringToAdd = re.sub('[^A-Za-z0-9_-]+', ' ', stringToAdd).strip()

    #split string on whitespace
    keywordsToAdd = stringToAdd.split()
    for keyword in keywordsToAdd:
        if keyword not in keywordsToIgnore and (len(keyword) > 1):
            keywordSet.add(keyword)




def add_swagger_api_to_search_index( apiRefDocFile, apiJson, searchIndexJson, apiSwaggerJson=None):
    '''
    for a local API described by apiJson, generate search entries for the API as appropriate and append them
    to searchIndexJson. If searchIndexJson is None, this is a noop.

    apiJson: the API to iterate/add to the index
    searchIndexJson: the output json data structure.  If None, no index is created.
    apiSwaggerJson: if this is a swagger API and this is provided, it is assumed that the calling code has
    already loaded it as swagger JSON and this is the json.  if not provided, then it will be loaded.

    '''
    if not searchIndexJson or not apiJson:
        return

    # check the type of the api.
    if apiJson.type != 'swagger':
        stdout("SKIPPING non swagger API " + apiJson.api_uid)

    # create a search entry for the API itself
    apiEntry = Object()
    apiEntry.type = "api"
    apiEntry.api_uid = apiJson.api_uid
    keywords_set = set()
    apiEntry.url = apiJson.url
    add_string_to_keyword_set(apiJson.name,keywords_set)
    add_string_to_keyword_set(apiJson.description,keywords_set)

    apiEntry.keywords = list(keywords_set)
    searchIndexJson.entries.append(apiEntry)

    if apiSwaggerJson is None:
        with open(apiRefDocFile) as swagger_file:
            apiSwaggerJson = json.load(swagger_file)

    '''
    "paths" : {
    "/api/catalogItemTypes" : {
      "get" : {
        "tags" : [ "catalog" ],
        "summary" : "Get catalog item types",
        "description" : "Find all CatalogItemTypes that are available in the system.",
        "parameters" : [ {
          "name" : "page",
          "in" : "query",
          "description" : "Page Number",
          "required" : false,
          "type" : "integer",
          "default" : 1
        }, {
          "name" : "limit",
          "in" : "query",
          "description" : "Number of entries per page",
          "required" : false,
          "type" : "integer",
          "default" : 20
        }, {
    '''

    paths_dict = apiSwaggerJson.get("paths")
    for path_key in paths_dict.keys():
        stdout("processing path=" + path_key)

        # this is a dict from get, put, post, patch to object
        path_dict = paths_dict.get(path_key)

        path_http_methods = path_dict.keys()
        for http_method in path_http_methods:
            method_dict = path_dict.get(http_method)

            tags = method_dict.get("tags")
            if tags and len(tags) > 0:
                for tag in tags:
                    methodEntry = Object()
                    methodEntry.api_uid = apiJson.api_uid
                    methodEntry.type = "method"
                    methodEntry.path = http_method + " " + path_key
                    keywords_set = set()

                    if "operationId" in method_dict:
                        operationId = apixutils.swagger_fix_operationId(method_dict.get("operationId"))
                    else:
                        # create the operation id yourself using the path key
                        operationId = apixutils.swagger_path_to_operationId(http_method, path_key)

                    # http://localhost:8082/swagger-console.html?url=local/swagger/api-vra-network-service.json&host=&basePath=#!/data45service/post_api_catalog_providers_providerId_requests_bindingId_complete

                    methodEntry.url = "/swagger-console.html?url=" + apiJson.url + "&basePath=" +  apixutils.swagger_make_method_url(tag, operationId)

                    add_string_to_keyword_set(tag,keywords_set)
                    add_string_to_keyword_set(path_key,keywords_set)
                    if "summary" in method_dict:
                        add_string_to_keyword_set(method_dict.get("summary"),keywords_set)
                    if "description" in method_dict:
                        add_string_to_keyword_set(method_dict.get("description"),keywords_set)

                    # TODO parameters
                    methodEntry.keywords = list(keywords_set)
                    searchIndexJson.entries.append(methodEntry)



    return

def stage_local_swagger2(swaggerJsonFilesToStage, outputJson, outputDir, args, searchIndexJson):

    if not swaggerJsonFilesToStage or len(swaggerJsonFilesToStage) == 0:
        return;

    stdout("Staging local swagger files")

    outputFile = args.output_file
    htmlRootDir = args.html_root_dir
    template_overview_html_file_path = args.template_overview_html_file_path

    markdownConvertor = markdown2.Markdown()

    if not htmlRootDir and outputFile:
        htmlRootDir = os.path.dirname(outputFile)

    templateOverviewHtml = None
    #template_overview_html_file_path = os.path.join(htmlRootDir, "overview-template.html")
    if template_overview_html_file_path and os.path.isfile(template_overview_html_file_path):
        stdout("Reading overview template file %s" % template_overview_html_file_path)
        with open(template_overview_html_file_path, "r") as templateOverviewHtmlFile:
            templateOverviewHtml = templateOverviewHtmlFile.read()
            # fixup relative path to style sheet to be absolute
            templateOverviewHtml = templateOverviewHtml.replace("href=\"styles/", "href=\"/styles/")
    if not templateOverviewHtml:
        stdout("No overview template found.")

    for swaggerJsonFile in swaggerJsonFilesToStage:
        try:
            # read in json from the file
            with open(swaggerJsonFile) as swagger_file:
                if swaggerJsonFile.endswith(".json"):
                    json_data = json.load(swagger_file)
                else:
                    json_data = yaml.load(swagger_file)

                # {
                #  "swagger": "2.0",
                #  "info": {
                #    "version": "1.2",
                #    "title": "VMware vRealize Operations 6.2",
                title = json_data['info']['title']
                version = ""
                if not args.api_version:
                    try:
                        version = json_data['info']['version']
                        version = version.replace("-SNAPSHOT", "")  # drop any -SNAPSHOT from version number
                    except Exception as e:
                        stdout("    warning: swagger json '%s' has no version" % (swaggerJsonFile))
                else:
                    version = args.api_version

                full_md_description = ""
                plain_text_description = ""
                abbrev_md_description = ""
                try:
                    full_md_description = json_data['info']['description']

                    full_md_description, plain_text_description, abbrev_md_description = apixutils.abbreviate_markdown_text(full_md_description, args.abbreviate_description)

                except Exception as e:
                    stdout("    warning: swagger json '%s' has no description" % (swaggerJsonFile))

                # {
                #    "apis": [ {
                #        "name" : "NSX for vSphere API",
                #        "version" : "6.2",
                #        "url" : "db/swagger/api-nsx-6.2.json",
                #        "products": ["NSX"]
                #    }, {
                api = Object()  # a dict based python object that has a method to easily serialize to json
                if args.api_prepend:
                    api.name = args.api_prepend + title
                else:
                    api.name = title
                api.description = plain_text_description
                api.version = version
                api.resources = []
                api.products = []
                api.type = "swagger"

                stdout("Including '%s' version='%s' 'title='%s'" % (swaggerJsonFile, version, title))

                relativePathToSwaggerJsonFile = os.path.basename(swaggerJsonFile)  # default path

                api.api_uid = get_api_uid_for_file_name(relativePathToSwaggerJsonFile,api.name)
                stdout("    Creating api_uid=" + api.api_uid)

                if outputDir:
                    # need to stage the file to the given directory and then figure out the relative path
                    newSwaggerJsonPath = os.path.join(outputDir, os.path.basename(swaggerJsonFile))

                    if (args.generate_overview_html):
                        stdout("    Abbreviating description")

                        json_data['info']['description'] = abbrev_md_description

                        stdout("    Rewriting '%s' to '%s'" % (swaggerJsonFile, newSwaggerJsonPath))
                        with open(newSwaggerJsonPath, "w") as outputSwaggerJson:
                            json.dump(json_data, outputSwaggerJson, sort_keys=False, indent=4)

                        overviewBasePath, ext = os.path.splitext(newSwaggerJsonPath)

                        if full_md_description:

                            if args.generate_overview_md:
                                overviewMarkdownPath = os.path.join(outputDir, overviewBasePath + ".md")
                                stdout("    Writing overview markdown '%s'" % (overviewMarkdownPath))
                                with open(overviewMarkdownPath, "w") as outputOverviewMarkdownFile:
                                    outputOverviewMarkdownFile.write(full_md_description)

                            overviewHtmlPath = os.path.join(outputDir, overviewBasePath + ".html")
                            stdout("    Converting and writing overview html '%s'" % (overviewHtmlPath))
                            with open(overviewHtmlPath, "w") as outputOverviewHtmlFile:

                                overviewHtml = markdownConvertor.convert(full_md_description)
                                if templateOverviewHtml:
                                    # insert the converted markdown and write that so we get the style
                                    overviewHtml = templateOverviewHtml.replace("OVERVIEW-BODY-PLACEHOLDER", overviewHtml)
                                outputOverviewHtmlFile.write(overviewHtml)

                            relativePathToOverviewHtmlFile = os.path.relpath(overviewHtmlPath, htmlRootDir)
                            stdout("    Adding overview resource '%s'" % (relativePathToOverviewHtmlFile))
                            add_local_overview_resource(api, "API Overview", relativePathToOverviewHtmlFile)
                        else:
                            stdout("Description is empty, skipping creating overview HTML doc.")

                        # TODO translate to html
                        # TODO add resource for the overview

                    else:
                        if not (os.path.isfile(newSwaggerJsonPath) and os.path.samefile(swaggerJsonFile, newSwaggerJsonPath)):
                            stdout("Copying '%s' to '%s'" % (swaggerJsonFile, newSwaggerJsonPath))
                            shutil.copyfile(swaggerJsonFile, newSwaggerJsonPath)

                    if outputFile:
                        relativePathToSwaggerJsonFile = os.path.relpath(newSwaggerJsonPath, os.path.dirname(outputFile))
                elif outputFile:
                    # refer to the file in place.  figure out relative path from the local.json file to
                    # the api ref file to use as the URL to the file in the API.
                    relativePathToSwaggerJsonFile = os.path.relpath(swaggerJsonFile, os.path.dirname(outputFile))

                stdout("    as relative path '" + relativePathToSwaggerJsonFile + "'")
                api.url = relativePathToSwaggerJsonFile

                # append the products to it based on stuff in the file name
                if not args.product_name:
                    add_products_from_filename(api, swaggerJsonFile)
                else:
                    api.products.append(args.product_name)

                # add to the search index
                add_swagger_api_to_search_index( swaggerJsonFile, api, searchIndexJson, json_data)

                add_api(args,outputJson,api)

        except Exception as e:
            eprint("    exception parsing '%s'" % (swaggerJsonFile))
            eprint(traceback.format_exc())
            continue

def _get_raml_include_files( ramlFilePath ):
    '''
    return a string list of all paths that are included
    in the given raml file.  i.e. this algorithm collects
    values from all lines that have
    '''
    path_list = []
    RAML_INCLUDE_RE =  re.compile(r'^.*\!include[ \t]+(.*)$')

    with open(ramlFilePath,"r") as input_raml_file:
        input_raml_lines = input_raml_file.readlines()
        for line in input_raml_lines:
            m = RAML_INCLUDE_RE.match(line)
            if m:
                path_list.append(m.group(1))

    return path_list

def _rewrite_raml_removing_documentation(ramlFilePath, newRamlFilePath, raml_file, abbreviated_description):
    stdout("    Rewriting '%s' to '%s'" % (ramlFilePath, newRamlFilePath))
    YAML_TOP_LEVEL_TAG_RE =  re.compile(r'^[a-zA-Z]+\:$')
    with open(newRamlFilePath, "w") as output_raml_file:
        with open(ramlFilePath,"r") as input_raml_file:
            input_raml_lines = input_raml_file.readlines()
            # little state machine. we are going to simply drop all documentation lines
            state = 1
            #    BEFORE_DOCUMENTATION = 1
            #    IN_DOCUMENTATION = 2
            #    AFTER_DOCUMENTATION = 3
            for line in input_raml_lines:
                if state == 1:
                    if line.startswith("documentation:"):
                        state = 2
                elif state == 2:
                    if YAML_TOP_LEVEL_TAG_RE.search(line):
                        state = 3  # end state 2 and append this line
                if state != 2:
                    output_raml_file.write(line)

        #yaml.dump(raml_data,output_raml_file)

#     if not (os.path.isfile(newRamlFilePath) and os.path.samefile(ramlFilePath, newRamlFilePath)):
#         stdout("    Copying '%s' to '%s'" % (ramlFilePath, newRamlFilePath))
#         shutil.copyfile(ramlFilePath, newRamlFilePath)

# # https://stackoverflow.com/questions/528281/how-can-i-include-an-yaml-file-inside-another
# class YamlIncludeLoader(yaml.Loader):
#
#     def __init__(self, stream):
#         self._root = os.path.split(stream.name)[0]
#         super(YamlIncludeLoader, self).__init__(stream)
#
#     def include(self, node):
#         filename = os.path.join(self._root, self.construct_scalar(node))
#         with open(filename, 'r') as f:
#             return yaml.load(f, YamlIncludeLoader)

def stage_local_raml(ramlFilesToStage, outputJson, outputDir, args, searchIndexJson):

    #yaml=YAML(typ='safe')   # default if not specfied is round-trip
    #YamlIncludeLoader.add_constructor('!include', YamlIncludeLoader.include)
    if not ramlFilesToStage or len(ramlFilesToStage) == 0:
        return;

    stdout("Staging local RAML files")

    outputFile = args.output_file
    htmlRootDir = args.html_root_dir
    template_overview_html_file_path = args.template_overview_html_file_path

    markdownConvertor = markdown2.Markdown()

    if not htmlRootDir and outputFile:
        htmlRootDir = os.path.dirname(outputFile)

    templateOverviewHtml = None
    #template_overview_html_file_path = os.path.join(htmlRootDir, "overview-template.html")
    if template_overview_html_file_path and os.path.isfile(template_overview_html_file_path):
        stdout("Reading overview template file %s" % template_overview_html_file_path)
        with open(template_overview_html_file_path, "r") as templateOverviewHtmlFile:
            templateOverviewHtml = templateOverviewHtmlFile.read()
            # fixup relative path to style sheet to be absolute
            templateOverviewHtml = templateOverviewHtml.replace("href=\"styles/", "href=\"/styles/")
    if not templateOverviewHtml:
        stdout("No overview template found.")

    for ramlFilePath in ramlFilesToStage:

        title = "TODO"
        version = "TODO VERSION"
        full_md_description = ""
        plain_text_description = ""
        abbrev_md_description = ""


        try:

            # read in json from the file
            raml_file = None # FIXME RAML IS BROKEN  pyraml.parser.load(ramlFilePath)

            #print raml_file

            #raml_data = yaml.load(raml_file, YamlIncludeLoader)
            #raml_data = yaml.load(raml_file)

            title = raml_file.title

            if not args.api_version:
                version = raml_file.version
            else:
                version = args.api_version

            documentation_list = raml_file.documentation

            if documentation_list and len(documentation_list) > 0:
                for document_obj in documentation_list:
                    doc_title = document_obj.title
                    doc_content = None
                    # doc_content here can either be a string directly, or it can in fact be a JSON string for an object that is an indirection.
                    try:
                        content_json = json.loads(document_obj.content)
                        doc_content = content_json.get("content")
                    except Exception as e:
                        doc_content = document_obj.content

                    full_md_description = full_md_description + "\n" + "# " + doc_title + "\n" + doc_content

            full_md_description, plain_text_description, abbrev_md_description = apixutils.abbreviate_markdown_text(full_md_description, args.abbreviate_description)

            api = Object()  # a dict based python object that has a method to easily serialize to json
            if args.api_prepend:
                api.name = args.api_prepend + title
            else:
                api.name = title
            api.description = plain_text_description
            api.version = version
            api.resources = []
            api.products = []
            api.type = "raml"

            stdout("Including '%s' version='%s' 'title='%s'" % (ramlFilePath, version, title))

            relativePathToramlFile = os.path.basename(ramlFilePath)  # default path

            api.api_uid = get_api_uid_for_file_name(relativePathToramlFile,api.name)
            stdout("    Creating api_uid=" + api.api_uid)

            if outputDir:
                # need to stage the file to the given directory and then figure out the relative path
                newRamlFilePath = os.path.join(outputDir, os.path.basename(ramlFilePath))

                if (args.generate_overview_html):
                    stdout("    Abbreviating description")

                    _rewrite_raml_removing_documentation(ramlFilePath, newRamlFilePath, raml_file, abbrev_md_description)

                    overviewBasePath, ext = os.path.splitext(newRamlFilePath)

                    if full_md_description:

                        if args.generate_overview_md:
                            overviewMarkdownPath = os.path.join(outputDir, overviewBasePath + ".md")
                            stdout("    Writing overview markdown '%s'" % (overviewMarkdownPath))
                            with open(overviewMarkdownPath, "w") as outputOverviewMarkdownFile:
                                sutf8 = full_md_description.encode('UTF-8')
                                outputOverviewMarkdownFile.write(sutf8)

                        overviewHtmlPath = os.path.join(outputDir, overviewBasePath + ".html")
                        stdout("    Converting and writing overview html '%s'" % (overviewHtmlPath))
                        with open(overviewHtmlPath, "w") as outputOverviewHtmlFile:

                            overviewHtml = markdownConvertor.convert(full_md_description)
                            if templateOverviewHtml:
                                # insert the converted markdown and write that so we get the style
                                overviewHtml = templateOverviewHtml.replace("OVERVIEW-BODY-PLACEHOLDER", overviewHtml)

                            sutf8 = overviewHtml.encode('UTF-8')
                            outputOverviewHtmlFile.write(sutf8)

                        relativePathToOverviewHtmlFile = os.path.relpath(overviewHtmlPath, htmlRootDir)
                        stdout("    Adding overview resource '%s'" % (relativePathToOverviewHtmlFile))
                        add_local_overview_resource(api, "API Overview", relativePathToOverviewHtmlFile)
                    else:
                        stdout("    Description is empty, skipping creating overview HTML doc.")

                else:
                    # not generating the overview, simply copy the file
                    if not (os.path.isfile(newRamlFilePath) and os.path.samefile(ramlFilePath, newRamlFilePath)):
                        stdout("    Copying '%s' to '%s'" % (ramlFilePath, newRamlFilePath))
                        shutil.copyfile(ramlFilePath, newRamlFilePath)

                include_files = _get_raml_include_files(ramlFilePath)
                if include_files:
                    for include_file in include_files:
                        srcIncludeFile = os.path.join(os.path.dirname(ramlFilePath),include_file)
                        if os.path.isfile(srcIncludeFile):
                            destIncludePath = os.path.join(outputDir, include_file)
                            dest_dir = os.path.dirname(destIncludePath)
                            if not os.path.isdir(dest_dir):
                                os.makedirs(dest_dir)
                            stdout("    Copying include '%s' to '%s'" % (srcIncludeFile, destIncludePath))
                            shutil.copyfile(srcIncludeFile, destIncludePath)
                        else:
                            stderr("    ERROR: src include file '%s' does not exist." % (srcIncludeFile))

                if outputFile:
                    relativePathToramlFile = os.path.relpath(newRamlFilePath, os.path.dirname(outputFile))

            elif outputFile:
                # refer to the file in place.  figure out relative path from the local.json file to
                # the api ref file to use as the URL to the file in the API.
                relativePathToramlFile = os.path.relpath(ramlFilePath, os.path.dirname(outputFile))

            stdout("    as relative path '" + relativePathToramlFile + "'")
            api.url = relativePathToramlFile

            # append the products to it based on stuff in the file name
            if not args.product_name:
                add_products_from_filename(api, ramlFilePath)
            else:
                api.products.append(args.product_name)

            # add to the search index
            #FIXME RAML SUPPORT FOR SEARCH INDEX?
            #add_swagger_api_to_search_index( ramlFilePath, api, searchIndexJson, json_data)

            add_api(args,outputJson,api)

        except Exception as e:
            eprint("    exception parsing '%s'" % (ramlFilePath))
            eprint(traceback.format_exc())
            continue

def stage_api_urls(args, api_type, urllist, outputJson):
    for url in urllist:
            metadataArray = url.split(',')
            api = Object()
            api.name = None
            api.url = None
            api.products = []
            api.resources = []  # TODO support for resources.
            api.version = ''
            api.type = api_type # swagger or raml
            for metadata in metadataArray:
                nameValue = metadata.split("=")
                if 'nam' in nameValue[0]:
                    api.name = nameValue[1].strip()
                elif 'des' in nameValue[0]:
                    api.description = nameValue[1].strip()
                elif 'ver' in nameValue[0]:
                    api.version = nameValue[1].strip()
                elif 'url' in nameValue[0]:
                    api.url = nameValue[1].strip()
                elif 'pro' in nameValue[0]:
                    api.products.append(nameValue[1].strip())
                elif 'uid' in nameValue[0]:
                    api.api_uid = nameValue[1].strip()
            if api.name and api.url:
                add_api(args,outputJson,api)
            else:
                eprint('ERROR: incorrect format format for api URL.  Must at least have name and url\n')
                #parser.print_help()
                exit(1)


def _contains_string(str_to_check, string_list):
    '''
    check to see if any of the strings in string_list are contained
    within str_to_check
    '''
    if not str_to_check or not string_list:
        return False

    for s in string_list:
        if s in str_to_check:
            return True
    return False

def scan_for_url_patterns(args, download_dir):
    '''
    Connects to an APIx server, gets a list of all APIs and then scans then all
    for any strings that match the given patterns in the resource/file URLs
    '''
    global apisSkipped

    client = apixutils.create_apix_client(args)
    apisApi = vmware_apix_client.apis.ApisApi(client)

    stdout("Getting list of all APIs...")
    apiList = apisApi.get_apis()
    matched_ref_docs = 0
    matched_resource_docs = 0

    for currentApi in apiList:

        emittedApiInfo = False

        # call get again to get full details including releases and tags
        #currentApi = apisApi.get_api(currentApi.id)

        if (_contains_string(currentApi.api_ref_doc_url,args.scan_for_url_pattern)):
            matched_ref_docs = matched_ref_docs + 1
            if not emittedApiInfo:
                emittedApiInfo = True
                stdout("\nAPI id=" + apixutils.safe_str(currentApi.id) + " api_uid="+apixutils.safe_str(currentApi.api_uid) + " name='" + apixutils.safe_str(currentApi.name) + "' version='" +  apixutils.safe_str(currentApi.version) + "'")

            stdout("    MATCH REFDOC=" + safe_str(currentApi.api_ref_doc_url))

        online_resources = apisApi.get_api_resources(currentApi.id)
        if online_resources:
            for online_resource in online_resources:

                if _contains_string(online_resource.web_url,args.scan_for_url_pattern) or  _contains_string(online_resource.download_url,args.scan_for_url_pattern):
                    matched_resource_docs = matched_resource_docs + 1

                    if not emittedApiInfo:
                        emittedApiInfo = True
                        stdout("\nCHECKING id=" + apixutils.safe_str(currentApi.id) + " api_uid="+apixutils.safe_str(currentApi.api_uid) + " name='" + apixutils.safe_str(currentApi.name) + "' version='" +  apixutils.safe_str(currentApi.version) + "'")
                    stdout("    MATCH RESOURCE name='" + apixutils.safe_str(online_resource.name) + "' web_url='" + apixutils.safe_str(online_resource.web_url) + "' download_url='" + apixutils.safe_str(online_resource.download_url) + "'")

                    if  download_dir and is_downloadable_file(online_resource.web_url):
                        apixutils.download_file(online_resource.web_url,dir=download_dir)

                    if  download_dir and is_downloadable_file(online_resource.download_url):
                        apixutils.download_file(online_resource.download_url,dir=download_dir)

    stdout("Checked " + str(len(apiList)) + " apis.  matched_ref_docs=" + str(matched_ref_docs) + " matched_resource_docs=" + str(matched_resource_docs))

from vmware_apix_client.models import Api
'''
new iterative mirror algorithm:

1) get filtered list of APIs to into apis_to_check list.
2) load current local list of APIs that are mirrored from local.json (will be 0 first time)
3) iterate apis_to_check.  if we do not have it locally add it to the list to sync/mirror. If
   we do have it locally, get the last update time of each API using new service that
   tells update time including all artifacts/resources.  Check this against the last update
   timestamp that was persisted when we last synchronized/mirrored.  If our local timestamp is
   older or doesn't exist, add it to the apis_to_mirror list.
4) iterate local.json and get list of APIs that have been removed.
5) iterate apis that have been removed and delete all files associated with them from the file system.
6) iterate apis_to_mirror synchronizing them and creating new local.json.  Take the timestamp
    for the API in step 3 and save that as the lastUpdated timestamp in local.json.
7) rename old local.json, and rename new local.json
8) DONE

'''
def handle_command_mirror(args):

    apisAlreadyUpToDate = 0

    verbose = args.verbose

    client = apixutils.create_apix_client(args)
    apisApi = vmware_apix_client.apis.ApisApi(client)
    supportedDocTypes = ["SWAGGER", "RAML"]

    _load_api_uid_mappings(args)

    outputJson = Object()
    outputJson.apis = []

    if not args.input_file:
        stderr("ERROR: you must provide input_file argument for mirror command.")
        exit(1)

    if args.mirror_output_dir:
        output_dir = os.path.abspath(args.mirror_output_dir)
    else:
        stderr("ERROR: you must provide mirror_output_dir argument for mirror command.")
        exit(1)

    if not os.path.isdir(output_dir):
        os.makedirs(output_dir)

    stdout("Staging all mirrored content to " + output_dir)

    current_local_apis = []

    if os.path.isfile(args.input_file):
        stdout("Reading local APIs from " + args.input_file)
        with open(args.input_file, "r") as input_json_file:
            jsonFromFile = json.loads(input_json_file.read())
            if jsonFromFile and "apis" in jsonFromFile:
                current_local_apis_json = jsonFromFile.get("apis")
                for dictObj in current_local_apis_json:
                    current_local_apis.append(objectview(dictObj))
    else:
        stdout("Local API file '" + args.input_file + "' does not exist, assuming that is normal.")

    stdout("input local.json contains %d apis." % (len(current_local_apis)))

    stdout("Getting latest APIs from server...")
    apis_to_check = []
    all_apis_list = apisApi.get_apis()
    apisSkipped = 0
    stdout("%d APIs received from server, filtering..." % (len(all_apis_list)))
    for currentApi in all_apis_list:

        if args.mirror_api and (len(args.mirror_api) > 0) and (currentApi.api_uid not in args.mirror_api):
            stdout("    Filtering id=" + str(currentApi.id) + " api_uid="+currentApi.api_uid + " name='" + currentApi.name + "'.  Not in mirror list.")
            apisSkipped = apisSkipped + 1
            continue
        if not currentApi.api_ref_doc_url or (currentApi.api_ref_doc_url == 'dummy'):
            stdout("    Filtering id=" + safe_str(currentApi.id) + " api_uid="+currentApi.api_uid + " name='" + currentApi.name + "'.  Doc URL is empty")
            apisSkipped = apisSkipped + 1
            continue

        # check the type of the API to see if we skip it or not
        if currentApi.api_ref_doc_type not in supportedDocTypes:
            docTypeString = "None"
            if currentApi.api_ref_doc_type:
                docTypeString = str(currentApi.api_ref_doc_type)
            stdout("    Filtering id=" + str(currentApi.id) + " api_uid="+currentApi.api_uid + " name=" + currentApi.name + " doc type is " + docTypeString + " url=" + safe_str(currentApi.api_ref_doc_url))
            apisSkipped = apisSkipped + 1
            continue
        apis_to_check.append(currentApi)

    stdout("There are %d apis to check.  %d apis filtered out." % (len(apis_to_check), apisSkipped))

    stdout("Iterating local APIs and checking timestamps against the latest APIs")
    for api in apis_to_check:
        api_last_modified = apisApi.get_api_resource_last_modified(api.id)
        stdout("Checking api id=%d uid=%s name=%s version=%s last_modified=%s" % (api.id, api.api_uid, api.name, api.version, api_last_modified))

        # find this api in the local list
        matching_local_api = None
        for local_api in current_local_apis:
            if (local_api.name == api.name) and (local_api.version == api.version):
                matching_local_api = local_api
                break

        mirror_this_api = True
        if matching_local_api:
            # there is a matching local API, check timestamps
            if hasattr(local_api,'api_last_modified') and local_api.api_last_modified == api_last_modified:
                stdout("    API already up to date, skipping mirror.")
                add_api(args,outputJson,matching_local_api)
                mirror_this_api = False
                apisAlreadyUpToDate = apisAlreadyUpToDate + 1
            else:
                # we need to mirror this API and stage all content from it
                stdout("    API is not up to date, mirroring...")
                mirror_this_api = True
        else:
            # there is no matching api locally, add it to the mirror list
            stdout("    API is not present locally, mirroring...")
            mirror_this_api = True

        if mirror_this_api:
            # set timestamp of the api to this last modified value
            mirror_api(args, api, api_last_modified, output_dir,outputJson,apisApi)

    if args.output_file:
        stdout("Writing %d apis to local index file %s" % (len(outputJson.apis), args.output_file))
        with open(args.output_file, "w") as output_json_file:
            output_json_file.write(outputJson.toJSON())

    stdout("%d apis written total.  %d apis mirrored, %d apis already up to date." %(apisAdded, apisMirrored, apisAlreadyUpToDate))


def mirror_api(args, currentApi, api_last_modified, output_dir, outputJson, apisApi):
    global apisMirrored
    # call get again to get full details including releases and tags
    currentApi = apisApi.get_api(currentApi.id)

    api_dir = os.path.join(output_dir,currentApi.api_uid)
    if not os.path.isdir(api_dir):
        os.makedirs(api_dir)

    stdout("    id=" + str(currentApi.id) + " api_uid="+currentApi.api_uid + " name=" + currentApi.name + " staged in:" + api_dir)

    apiJson = Object()  # a dict based python object that has a method to easily serialize to json
    apiJson.name = currentApi.name
    apiJson.api_uid = currentApi.api_uid
    apiJson.api_last_modified = api_last_modified
    apiJson.description = currentApi.description
    apiJson.version = currentApi.version
    apiJson.resources = []
    apiJson.products = []
    apiJson.type = str(currentApi.api_ref_doc_type).lower()

    # download the reference doc to local
    try:
        apiRefDocPath = apixutils.download_file(currentApi.api_ref_doc_url, dir=api_dir)
    except Exception as e:
        eprint("    exception downloading url='%s'" % (safe_str(currentApi.api_ref_doc_url)))
        eprint("    skipping api " + str(currentApi.id))
        eprint(traceback.format_exc())
        return

    relativeFilePath = os.path.relpath(apiRefDocPath, args.html_root_dir)
    apiJson.url = relativeFilePath

    if currentApi.releases:
        for release in currentApi.releases:
            product = release.name + ";" + release.version
            apiJson.products.append(product)

    online_resources = apisApi.get_api_resources(currentApi.id)
    if online_resources:
        for online_resource in online_resources:
            if online_resource.resource_type in "DOC":
                local_resource = online_resource_to_local_resource(online_resource,args.downloaddocs, api_dir,args.html_root_dir)
                apiJson.resources.append(local_resource)
            elif online_resource.resource_type in "SDK":
                local_resource = online_resource_to_local_resource(online_resource,args.downloadsdks, api_dir,args.html_root_dir)
                apiJson.resources.append(local_resource)
            else:
                #simple append the online resource so we have it
                #local_resource = online_resource_to_local_resource(online_resource,False, api_dir,args.html_root_dir)
                apiJson.resources.append(online_resource)

    add_api(args,outputJson,apiJson)

    apisMirrored = apisMirrored + 1



def mirror_apix_server_to_local(args, html_root_dir, output_dir, outputJson, searchIndexJson):
    '''
    Connects to an APIx server, gets a list of all APIs and then mirrors all
    Swagger and RAML based APIs to a local cache
    html_root_dir : the directory on disk that is assumed to be the HTML root,
       that is the directory that all links should be absolute relative to.
    output_dir: the directory to mirror the content under.  must be located
      under html_root_dir.
      outputJson: the JSON output object, has outputJson.apis which is a list
      of local api objects.
    '''
    global apisSkipped

    client = apixutils.create_apix_client(args)

    apisApi = vmware_apix_client.apis.ApisApi(client)

    supportedDocTypes = ["SWAGGER", "RAML"]

    stdout("Getting list of all APIs...")
    apiList = apisApi.get_apis()
    for currentApi in apiList:

        if args.mirror_api and (len(args.mirror_api) > 0) and (currentApi.api_uid not in args.mirror_api):
            stdout("SKIPPING id=" + str(currentApi.id) + " api_uid="+currentApi.api_uid + " name='" + currentApi.name + "'.  Not in mirror list.")
            apisSkipped = apisSkipped + 1
            continue
        #currentApi2 = Api()

        if not currentApi.api_ref_doc_url or (currentApi.api_ref_doc_url == 'dummy'):
            stdout("SKIPPING id=" + safe_str(currentApi.id) + " api_uid="+currentApi.api_uid + " name='" + currentApi.name + "'.  Doc URL is empty")
            apisSkipped = apisSkipped + 1
            continue

        # check the type of the API to see if we skip it or not
        if currentApi.api_ref_doc_type not in supportedDocTypes:
            docTypeString = "None"
            if currentApi.api_ref_doc_type:
                docTypeString = str(currentApi.api_ref_doc_type)
            stdout("SKIPPING id=" + str(currentApi.id) + " api_uid="+currentApi.api_uid + " name=" + currentApi.name + " doc type is " + docTypeString)
            stdout("    url=" + safe_str(currentApi.api_ref_doc_url))
            apisSkipped = apisSkipped + 1
            continue

        # call get again to get full details including releases and tags
        mirror_api(currentApi, html_root_dir,output_dir,outputJson,apisApi)


def handle_command_stage(args):

    _load_api_uid_mappings(args)

    if args.search_index_output_file:
        searchIndexJson = Object()
        searchIndexJson.entries = []
    else:
        searchIndexJson = None

    outputJson = Object()
    outputJson.apis = []

    if args.input_file and  os.path.isfile(args.input_file):
        stdout("Reading local.json file as input " + args.input_file)
        with open(args.input_file, "r") as input_json_file:
            jsonFromFile = json.loads(input_json_file.read())
            if jsonFromFile and "apis" in jsonFromFile:
                outputJson.apis = jsonFromFile.get("apis")

    mirror_output_dir = None
    if args.mirror_output_dir:
        mirror_output_dir = os.path.abspath(args.mirror_output_dir)

        if not os.path.isdir(mirror_output_dir):
            os.makedirs(mirror_output_dir)

        stdout("Staging all mirrored content to " + mirror_output_dir)

        mirror_apix_server_to_local(args, args.html_root_dir, mirror_output_dir, outputJson, searchIndexJson)
    else:
        stdout("Not mirroring content, mirror_output_dir arg not provided.")

    swaggerJsonFilesToStage = []
    if args.swagger_glob:
        for swagger_glob in args.swagger_glob:
            globMatches = glob.glob(swagger_glob)
            for g in globMatches:
                swaggerJsonFilesToStage.append(g)

    ramlFilesToStage = []
    if args.raml_glob:
        for ramlglob in args.raml_glob:
            globMatches = glob.glob(ramlglob)
            for g in globMatches:
                ramlFilesToStage.append(g)

    # stage any urls manually specified
    if args.swagger_url:
        stage_api_urls(args, 'swagger', args.swagger_url, outputJson)

        # stage any urls manually specified
    if args.raml_url:
        stage_api_urls(args, 'raml', args.raml_url, outputJson)

    if len(swaggerJsonFilesToStage) > 0:
        swagger_output_dir = None
        if not args.swagger_output_dir:
            stderr("you must provide swagger_output_dir argument.")
            exit(1)
        swagger_output_dir = os.path.abspath(args.swagger_output_dir)
        if not os.path.isdir(swagger_output_dir):
            os.makedirs(swagger_output_dir)
        stdout("Staging all local Swagger content to " + swagger_output_dir)
        stage_local_swagger2(swaggerJsonFilesToStage, outputJson, swagger_output_dir, args, searchIndexJson)

    if len(ramlFilesToStage) > 0:
        if not args.raml_output_dir:
            stderr("you must provide raml_output_dir argument.")
            exit(1)
        raml_output_dir = os.path.abspath(args.raml_output_dir)
        if not os.path.isdir(raml_output_dir):
            os.makedirs(raml_output_dir)
        stdout("Staging all local RAML content to " + raml_output_dir)
        stage_local_raml(ramlFilesToStage, outputJson, raml_output_dir, args, searchIndexJson)

    if args.output_file:
        stdout("Writing %d apis to local index file %s" % (len(outputJson.apis), args.output_file))
        with open(args.output_file, "w") as output_json_file:
            output_json_file.write(outputJson.toJSON())

    if args.search_index_output_file:
        stdout("Writing %d entries to search index file %s" % (len(searchIndexJson.entries), args.search_index_output_file))
        with open(args.search_index_output_file, "w") as search_index_json_file:
            search_index_json_file.write(searchIndexJson.toJSON())

    stdout("%d apis added.  %d apis skipped due to unsupported format (html). %d duplicate apis dropped." %(apisAdded, apisSkipped, apisDropped))

def handle_command_download(parser, args):

    if not args.swagger_output_dir:
        stderr("you must provide swagger_output_dir argument.")
        exit(1)

    if not args.arguments:
        stderr("you must provide at least one URL argument.")
        exit(1)

    swagger_output_dir = os.path.abspath(args.swagger_output_dir)

    if not os.path.isdir(swagger_output_dir):
        os.makedirs(swagger_output_dir)

    stdout("Staging all local Swagger content to " + swagger_output_dir)

    # code to download swagger and embedded markdown along with all relative files
    for swagger_url in args.arguments:
        download_swagger( swagger_url, swagger_output_dir, args.verbose )

def handle_command_scan_for_url_patterns(args):
    if args.scan_for_url_pattern:

        url_pattern_output_dir = None
        if args.url_pattern_output_dir:
            url_pattern_output_dir = os.path.abspath(args.url_pattern_output_dir)
        if not os.path.isdir(url_pattern_output_dir):
            os.makedirs(url_pattern_output_dir)
        scan_for_url_patterns(args,url_pattern_output_dir);


def handle_command( parser, args, command):
    '''
    routine to handle the given string command.  returns True if handled, False if unknown command.
    '''
    if command == 'help':
        parser.print_help()
        exit(1)
    elif command == 'stage':
        handle_command_stage(args)
    elif command == 'download':
        handle_command_download(parser,args)
    elif command == 'scan_for_url_patterns':
        handle_command_scan_for_url_patterns(args)
    elif command == 'mirror':
        handle_command_mirror(args)
    else:
        return False

    return True;

command_name = "apixlocal"
build_version="0.9"
# NOTE: the BUILD_DATE value below gets replaced during a packaging/build with a timestamp
build_date="BUILD_DATE"

commandHelpInfo = "\
Command to run.  One of:\n\
stage                 : stage local content into the specified directories.\n\
download              : download swagger content.\n\
scan_for_url_patterns : scan all API documents on the server for the specified patterns.\n"


def create_argument_parser():
    # parser shared by all commands
    # parser shared by all commands
    parser = argparse.ArgumentParser(description="API Explorer component command line tool.",
                                      usage=command_name + " COMMAND [OPTIONS]")

    parser.add_argument('command', help=commandHelpInfo)

    parser.add_argument('--verbose', help=' Verbose display of results',action='store_true')
    parser.set_defaults(verbose=False)

    parser.add_argument('--version', dest='version', action='store_true',
                        help="Show version information and exit.")
    #parser.add_argument('--dryrun', dest='dryrun', action='store_true',
    #                    help="Perform a dry run only, reporting what the tool would do without making any changes.")
    #parser.set_defaults(dryrun=False)

    parser.add_argument('--input_file', help='Optional path to a local.json file to merge into the local.json output.  Cannot be the same file.')
    parser.add_argument('--output_file', help='Path to local.json file for output API metadata')
    parser.add_argument('--search_index_output_file', help='Path to search-index.json file for creation of search index if applicable.')
    parser.add_argument('--html_root_dir', help='Root directory for generated relative links.')

    parser.add_argument('--allow_duplicates', dest='checkduplicates', action='store_false',
                        help="If specified, no checking is done between local APIs and mirrored APIs for duplication.  Default is to check.")
    parser.set_defaults(checkduplicates=True)

    # ARGUMENTS FOR MIRRORING FEATURES
    parser.add_argument('--server', help='Full server URL.  Only needed if you are targeting one of the test servers.')
    parser.set_defaults(server="https://dc-prod-repo1.vmware.com:8443/dcr/rest")
    parser.add_argument('--user', help='MyVMware email address to use for authentication. Must be supplied.')
    parser.add_argument('--password', help='MyVMware password to use for authentication.  Note that https with basic auth is used for authentication and this is saved nowhere.')
    parser.add_argument('--mirror_output_dir', help='Root directory in which to stage all mirrored API reference documents')
    parser.add_argument('--mirror_api', dest="mirror_api", action="append", help='Optional API uids to include in the mirror.  If specified only values provided are mirrored.')
    parser.add_argument('--download_sdks', dest='downloadsdks', action='store_true',
                        help="If provided, download SDK binaries locally.  Default is False as this can use substantial disk space.")
    parser.set_defaults(downloadsdks=False)
    parser.add_argument('--no_download_docs', dest='downloaddocs', action='store_false',
                        help="If provided, do NOT download extra resource documents locally (e.g. PDFs).")
    parser.set_defaults(downloaddocs=True)

    # ARGUMENTS FOR LOCAL SWAGGER FEATURES
    parser.add_argument('--swagger_output_dir', help='Root directory in which to stage all local swagger API reference documents')
    parser.add_argument('--swagger_glob', nargs='+', help='One or more glob paths to match swagger json files stage.  e.g. path/to/*.json', required=False)
    parser.add_argument('--swagger_url', nargs='+', help='One or more swagger urls. argument should be name=<value,description=<value>,version=<value>,url=<value>,product=<value>', required=False)
    # args for RAML
    parser.add_argument('--raml_output_dir', help='Root directory in which to stage all local RAML API reference documents')
    parser.add_argument('--raml_glob', nargs='+', help='One or more glob paths to match RAML files stage.  e.g. path/to/*.raml', required=False)
    parser.add_argument('--raml_url', nargs='+', help='One or more RAML urls. argument should be name=<value,description=<value>,version=<value>,url=<value>,product=<value>', required=False)
    # applicable to swagger and RAML
    parser.add_argument('--product_name', help='Optional product name string to user for all APIs')
    parser.add_argument('--api_version', help='Optional API version string override to use for all APIs')
    parser.add_argument('--api_prepend', help='Optional string to prepend to all API names.')
    parser.add_argument('--abbreviate_description', help='If provided, abbreviate the description to only be the first line.', action='store_true')
    parser.add_argument('--generate_overview_html', help='If provided, generate overview HTML in the output directory', action='store_true')
    parser.add_argument('--generate_overview_md', help='If provided, generate overview markdown file in the output directory', action='store_true')
    parser.add_argument('--template_overview_html_file_path', help='If provided, use the specified template HTML to inject overview HTML into.')

    parser.add_argument('--file_name_to_api_uid_properties_file_path', help='If provided, a path to a properties file containing mappings from file names to API uid strings.  fileName.ext=api_uid with # comments.')

    parser.add_argument('--scan_for_url_pattern', nargs='+', help='One or more string values to look for in URLs.  anything that matches is dumped.', required=False)
    parser.add_argument('--url_pattern_output_dir', help='Directory to stage matching downloadable files that match scan_for_url_pattern')

    parser.add_argument('arguments', nargs='*', help='Command specific arguments (paths, expressions, etc)')

    return parser

def main(argv):

    stdout(command_name + " version=" + build_version + " build_date=" + build_date + " starting...")

    parser = create_argument_parser()

    if len(argv) == 0:
        parser.print_help()
        exit(1)

    args = parser.parse_args(args=argv)

    if (args.version):
        stdout(command_name + " version=" + build_version + " build_date=" + build_date)
        exit(0)

    handle_command(parser, args, args.command)

    stdout("DONE!")

if __name__ == "__main__":
    main(sys.argv[1:])
