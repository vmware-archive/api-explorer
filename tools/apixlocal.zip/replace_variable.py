"""
Copyright (c) 2016,  VMware Inc., All Rights Reserved.

This file is open source software released under the terms of the
BSD 3-Clause license, https://opensource.org/licenses/BSD-3-Clause:

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
 may be used to endorse or promote products derived from this software without
 specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

###############################################################################

This file is a utility meant to do a find/replace on API Explorer config.js
files.  Why?  because it is really painful to call sed from a shell script
when there are variables and quotes and dots.  This utility has none of those
issues.  USAGE:

replace_variable.py --verbose \
--variable_name=window.config.authApiEndPoint \
--variable_value=https://the-correct-hostname.eng.vmware.com \
/home/aspear/tmp/config.js

"""

# --------------------------------------------------------------------
# standard python imports
import argparse
import re
import sys
import os
import shutil
import traceback
import glob

# this code attempts to get the column size.  this will fail if this is not a tty, e.g. running
# in a script, which which case it defaults to some sane value.  At some point when this is migrated
# to Python 3.3+ , change to str(shutil.get_terminal_size().columns)
os.environ['COLUMNS'] = '100'
try:
    if sys.stdout.isatty():
        rows, columns = os.popen('stty size', 'r').read().split()
        os.environ['COLUMNS'] = columns
except:
    pass

#all output goes through this one function in an effort to deal with python version differences
#in stdout support and perhaps also allow some graceful redirection
def stdout( lineString ):
    sys.stdout.write(lineString)
    sys.stdout.write("\n")

def stderr( lineString ):
    sys.stderr.write(lineString)
    sys.stderr.write("\n")

def _findSplitIndex(line):
    index=0
    while index != -1:
        index = line.find("=",index)
        if index > 0:
            c = line[index-1]
            if c != '\\':
                return index
        # not found search from next char
        index = index + 1
    return -1


def readRepFilePairs(repFilePath, nameValuePairMap):
    inputFile  = open(repFilePath,"r")
    if inputFile == False:
        stderr("ERROR: unable to open input file "+repFilePath)
        sys.exit(2)
    for line in inputFile.readlines():
        if line.startswith('#'):
            continue;
        line = line.strip()
        # find the first instance of '=' that is not escaped and split on that index.
        index = _findSplitIndex(line)
        if index > -1:
            name = line[:index]
            value = line[index+1:]
            # it is possible that there are escaped = chars. replace those with single equals chars
            name = name.replace("\=","=")
            value = value.replace("\=","=")
            nameValuePairMap[name] = value
    inputFile.close()

def _setFilePermissions( path, mode, uid, gid ):
    try:
        os.chown(path,uid,gid)
    except Exception as e:
        stderr("ERROR: while trying to change owner on '%s': %s\n" % (path, str(e)))
    try:
        os.chmod(path,mode)
    except Exception as e:
        stderr("ERROR: while trying to change mode '%s': %s\n" % (path, str(e)))

def replace( nameValuePairMap, filePathList, verbose, dryrun,noprintunchanged=False,useregexsub=False):
    '''
    This is a utility function that does find/replace of values accross a set of files.  For each file
    explicitly provided in the filePathList, the nameValuePairMap is iterated, and a find replace is
    performed on the file.
    nameValuePairMap : set of name value pairs
    filePathList : list of full file paths
    verbose : if True dump messages to stdout about operations performed.
    dryrun : if True, then only report on what we would do, don't actually do the replacement
    noprintunchanged : if this is True, do not print the number of files that were itereated but not changed.
    useregexsub : if True, the nameValuePairMap contains regular expressions
    '''

    if dryrun == True and verbose:
        stdout("Performing dry run")

    if verbose == True:
        for name,value in nameValuePairMap.items():
            stdout('NAME='+name+' VALUE='+value)

    totalFilesReplaced = 0

    if len(filePathList) == 0:
        stdout("NO FILES MATCHED SPECIFIED PATTERNS")
        sys.exit(1)

    for inputFileName in filePathList:
        changesInFile = 0

        if not noprintunchanged:    # yeah , sorry about the double negative
            stdout(inputFileName)
            emittedFileName = True
        else:
            emittedFileName = False

        try:
            outputFileName = inputFileName + ".temp";
            inputFile  = open(inputFileName,"r")
            if inputFile == False:
                stderr("ERROR: unable to open input file "+inputFileName)
                continue
            statstruct = os.stat(inputFileName)

            if dryrun == False:
                outputFile = open(outputFileName, "w")
            linenumber = 1
            for line in inputFile.readlines():
                newLine = line
                for key, value in nameValuePairMap.items():
                    if useregexsub:
                        newLine = re.sub(key, value, newLine)
                    else:
                        newLine = newLine.replace(key,value)
                if dryrun == False:
                    outputFile.write(newLine)

                if newLine != line:
                    changesInFile = changesInFile + 1
                    if not emittedFileName:
                        stdout(inputFileName)
                        emittedFileName = True
                    if (dryrun == True) or (verbose == True):
                        stdout("    " + str(linenumber)+": '"+ newLine.rstrip("\n") + "'")
                linenumber = linenumber + 1


            if dryrun == False:
                if changesInFile != 0:
                    stdout("    "  + str(changesInFile)+" lines changed")
            else:
                if verbose:
                    stdout("    "  + str(changesInFile)+" lines WOULD BE changed")
            if changesInFile != 0:
                totalFilesReplaced = totalFilesReplaced + 1

            inputFile.close();

            if dryrun == False:
                outputFile.close();
                os.remove(inputFileName)
                os.rename(outputFileName,inputFileName)
                _setFilePermissions( inputFileName, statstruct.st_mode, statstruct.st_uid, statstruct.st_gid )

        except Exception, inst:
            inputFile.close()
            if dryrun == False:
                outputFile.close()
            stderr("Exception while handling files")
            #, type(inst)     # the exception instance
            #print inst.args      # arguments stored in .args
            traceback.print_exc()
            sys.exit(1)

    if verbose or totalFilesReplaced != 0:
        if dryrun == False:
            stdout(str(totalFilesReplaced)+ " files changed.")
        else:
            stdout(str(totalFilesReplaced)+ " files WOULD BE changed.")

usage = "replace_variable.py --verbose \\\n" + \
        " --variable_name=window.config.authApiEndPoint \\\n" + \
        " --variable_value=https://the-correct-hostname.eng.vmware.com \\\n" + \
        " /home/aspear/tmp/config.js"

def create_argument_parser():
    parser = argparse.ArgumentParser(description="API Explorer config variable replacer.",
                                      usage=usage)

    parser.add_argument('--variable_value', help="config file variable new value string")
    parser.add_argument('--variable_name', dest='variablename', help='Text name of the variable to replace')
    parser.add_argument('--verbose', dest='verbose', action='store_true', help='Verbose display of results')
    parser.set_defaults(verbose=False)
    parser.add_argument('--dryrun', dest='dryrun', action='store_true',
                        help="Perform a dry run only, reporting what the tool would do without making any changes.")
    parser.set_defaults(dryrun=False)
    parser.add_argument('path', help="config file path glob")

    return parser

def replace_config_variable(args):
    variablename = "window.config.authApiEndPoint"
    if args.variablename:
        variablename = args.variablename

    regexstring = '([ \\t]+)' + variablename + '([ \\t]*)=([ \\t]*)"([^"]+)(.*)"'
    replstring = '\\1window.config.authApiEndPoint\\2=\\3"' + args.variable_value + '"\\5'

    nameValuePairMap = {}
    nameValuePairMap[regexstring] = replstring;

    filePathList = []
    globMatchingFiles = glob.glob(args.path)
    for f in globMatchingFiles:
        filePathList.append(f)

    replace( nameValuePairMap, filePathList, args.verbose, args.dryrun,noprintunchanged=False,useregexsub=True)


def main(argv):

    parser = create_argument_parser()

    if len(argv) == 0:
        parser.print_help()
        exit(1)

    args = parser.parse_args(args=argv)

    if not args.variable_value or not args.path:
        parser.print_help()
        exit(1)

    try:
        replace_config_variable(args)
    except Exception, e:
        sys.stderr.write(traceback.format_exc())
        exit(1)

if __name__ == "__main__":
    main(sys.argv[1:])
