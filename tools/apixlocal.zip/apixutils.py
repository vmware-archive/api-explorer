"""
Copyright (c) 2016,  VMware Inc., All Rights Reserved.

This file is open source software released under the terms of the
BSD 3-Clause license, https://opensource.org/licenses/BSD-3-Clause:

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
 may be used to endorse or promote products derived from this software without
 specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

###############################################################################

This file is a utility meant for contributing samples to VMware Sample Exchange,
https://developercenter.vmware.com/samples
"""
from __future__ import ( division, absolute_import, print_function, unicode_literals )
import re
import urllib
import urllib3
import sys
#import base64
import glob
import os
import string
import markdown2

from vmware_apix_client.models.tag import Tag




#import sys, os, tempfile, logging

# TODO uncomment this when we move to python 3 support
#if sys.version_info >= (3,):
#    import urllib.request as urllib2
#    import urllib.parse as urlparse
#else:
import urllib2
import urlparse

#from vmware_apix_client.models.category import Category


def stdout(lineString):
    sys.stdout.write(lineString)
    sys.stdout.write("\n")


def stderr(lineString):
    sys.stderr.write(lineString)
    sys.stderr.write("\n")

TAG_RE = re.compile(r'<[^>]+>')
WHITESPACE_RE = re.compile(r'[ \t\r\n]+')

def safe_str(obj):
    if obj:
        return str(obj)
    else:
        return "None"

def abbrev_html(input_html,maxlen=100):
    """
    remove all html from a description, consolidate whitespace, remove end of lines, and abbreviate at 100 chars.
    """
    if not input_html:
        return ""
    output = TAG_RE.sub('', input_html)
    output = WHITESPACE_RE.sub(' ', output)
    return (output[:maxlen] + '..') if len(output) > maxlen else output

tagCounter = 1

SLASH_RE = re.compile(r'[/ ]+')
CURLY_REMOVE_RE = re.compile(r'[{}]+')
SWAGGER_PATH_DASH_RE = re.compile(r'-')
SWAGGER_PATH_WS_RE = re.compile(r'[ \t]')
NOT_ALNUM_RE =  re.compile(r'[^A-Za-z0-9]+')

def swagger_path_to_operationId(httpMethod, swaggerOperationPath):
    '''
    create a swagger operation id from the method path such as /endpoints/types/extensions/{id}
    to get_endpoints_types_extensions_id
    '''
    if not swaggerOperationPath:
        return ""
    pathOperationId = swaggerOperationPath
    pathOperationId = CURLY_REMOVE_RE.sub('', pathOperationId)
    pathOperationId = SLASH_RE.sub('_', pathOperationId)

    return httpMethod + pathOperationId

def swagger_fix_operationId(operationId):
    '''
    make sure operation id is valid in case user messed it up
    '''
    if not operationId:
        return ""
    operationId = operationId.strip()
    operationId = NOT_ALNUM_RE.sub('_', operationId)
    return operationId

def swagger_make_method_url(tag, operationId):

    # I don't understand the pattern, but this is what swagger does, it puts the tag at the beginning of the method, and then
    # puts '45' for dashes and '32' for spaces, which appears to be the decimal for the ASCII char value, odd.  I guess this is their
    # own sort of URL encoding, albeit really stange.
    # TODO improve this algorithm to handle other characters as well.
    tagOperationId = SWAGGER_PATH_DASH_RE.sub('45', tag)
    tagOperationId = SWAGGER_PATH_WS_RE.sub('32', tagOperationId)

    # http://localhost:8082/swagger-console.html?url=local/swagger/api-vra-network-service.json&host=&basePath=#!/data45service/post_api_catalog_providers_providerId_requests_bindingId_complete
    url = "#!/" + tagOperationId + "/" + operationId
    return url

def read_file_body_as_utf8( file_path ):
    import codecs
    with codecs.open(file_path, "r", "utf-8") as f:
        return f.read()

def appendTagsAndCategories(tags, categories, contribution):
    """
     Append any tags from the tags and categories lists to the given Contribution object
    :param tags: list of strings for tags.  can optionally have category and value separated by colon.
    :param categories: list of strings for category values.  Can optionally have type and version separated via colon.
    """
    global tagCounter
    # append any extra tags
    if tags:
        for tagString in tags:
            tagString = urllib.unquote(tagString).decode('utf8')

            newTag = Tag()
            newTag.id = tagCounter
            tagCounter = tagCounter + 1

            if not contribution.tags:
                contribution.tags = []

            colonIndex = tagString.find(':')
            if colonIndex != -1:
                category, tag = tagString.split(":")
                newTag.category = category
                newTag.name = tag
            else:
                newTag.category = "Tags"
                newTag.name = tagString

            # check that the tag is not already in the set
            alreadyIn = False
            for currentTag in contribution.tags:
                if (currentTag.name == newTag.name) and (currentTag.category == newTag.category):
                    alreadyIn = True

            if not alreadyIn:
                contribution.tags.append(newTag)

#      append any extra categories
#     if categories:
#         for value in categories:
#             value = urllib.unquote(value).decode('utf8')
#
#             newCategory = Category()
#             newCategory.id = tagCounter
#             tagCounter = tagCounter + 1
#
#             if not contribution.categories:
#                 contribution.categories = []
#
#             colonIndex = value.find(':')
#             if colonIndex != -1:
#                 catType, version = value.split(":")
#                 newCategory.type = catType
#                 newCategory.version = version
#             else:
#                 newCategory.version = ""
#                 newCategory.type = value
#
#              check that category is not already in the set
#             alreadyIn = False
#             for currentCategory in contribution.categories:
#                 if (currentCategory.type == newCategory.type) and (currentCategory.version == newCategory.version):
#                     alreadyIn = True
#
#             if not alreadyIn:
#                 contribution.categories.append(newCategory)

def fixSampleTitle(name):
    name = string.capwords(name)
    name = name.replace("Vmware", "VMware");
    name = name.replace("Vcenter", "vCenter");
    name = name.replace("VCenter", "vCenter");
    name = name.replace("Vsphere", "vSphere");
    name = name.replace("VSphere", "vSphere");

    name = name.replace("Vcloud", "vCloud");
    name = name.replace("VCloud", "vCloud");
    name = name.replace("Vsan", "vSAN");
    name = name.replace("Vapp", "vApp");
    name = name.replace("VApp", "vApp");
    name = name.replace("VMotion", "vMotion");
    name = name.replace("Vmotion", "vMotion");
    name = name.replace("Vco", "vCO");
    name = name.replace("Vra", "vRA");
    name = name.replace("Vro", "vRO");
    name = name.replace("VSan", "vSAN");
    name = name.replace("VSAN", "vSAN");
    name = name.replace("vSANVM", "vSAN VM");
    name = name.replace("VApp", "vApp");
    name = name.replace("Esxi", "ESXi");
    name = name.replace("Vmdk", "VMDK");
    name = name.replace("Nsx", "NSX");
    name = name.replace("Vaai", "VAAI");
    name = name.replace("Vm ", "VM ");
    name = name.replace(" Vm", " VM");
    name = name.replace("VSphereAutoRestartManager", "vSphere Auto Restart Manager");
    name = name.replace("Getorphanedvms", "Get Orphaned VMs");
    name = name.replace("Getallvms", "Get All VMs");
    name = name.replace("Uuid", "UUID");
    name = name.replace(" Dc", " DC");
    name = name.replace("Ovf", "OVF");

    name = name.replace("Scsi", "SCSI");
    name = name.replace("Sata", "SATA");
    name = name.replace("Iso", "ISO");
    name = name.replace("Cpu", "CPU");
    name = name.replace("Crud", "CRUD");

    name = name.replace("Cls", "CLS");
    name = name.replace("Api", "API");
    name = name.replace("Sdk", "SDK");
    name = name.replace("Psc", "PSC");
    name = name.replace("Sso", "SSO");
    name = name.replace("Create Create", "Create");

    return name



def findFiles(directoryPath, globPattern, recursive, filePathList, verbose):
    '''
    For a given directory and glob pattern, scan for files that match the glob and
    append the full paths to the file to the filePathList.

    directoryPath: string path to scan in

    globPattern: string glob to search for, e.g. "*.java"

    recursive: if True, then we recurse into subdirectories looking for the files as well

    filePathList: output param, string list to append full paths to

    verbose: if True print the names of directories to stdout as we enter them
    '''
    for dirpath, dirnames, filenames in os.walk(directoryPath):
        if verbose:
            stdout("Scanning dir %s" % dirpath)
        # os.chdir(dirpath)
        globMatchingFiles = glob.glob1(dirpath, globPattern)
        for f in globMatchingFiles:
            filePathList.append(os.path.join(dirpath, f))
        if not recursive:
            while len(dirnames) > 0:
                dirnames.pop()
        #directoriesScanned.append(dirpath)

def extract_markdown_relative_links(markdown_text):
    '''
    Returns a list of strings that are relative hyper links
    found in the given text.  No checking as to whether or not the
    content is really markdown, only whether or not it has valid markdown links.
    '''
    link_list = []

    # markdown links are of the format [<optional text>](link)
    pattern = re.compile(r'!\[([^\]]*)\][ \t]*\(([^\)]+)\)')

    for (title, url) in re.findall(pattern, markdown_text):
        #stdout("title='" + title + "' value='" + url + "'")
        link_list.append(url)

    return link_list


def download_file(url, dir=None, verbose=None):
    '''
    Download a file from the given URL.
    dir: optional path to place the file in
    '''
    u = urllib2.urlopen(url)

    scheme, netloc, path, query, fragment = urlparse.urlsplit(url)
    filename = os.path.basename(path)
    if not filename:
        filename = 'downloaded.file'
    if dir:
        filename = os.path.join(dir, filename)

    with open(filename, 'wb') as f:
        meta = u.info()
        meta_func = meta.getheaders if hasattr(meta, 'getheaders') else meta.get_all
        meta_length = meta_func("Content-Length")
        file_size = None
        if meta_length:
            file_size = int(meta_length[0])
        print("    Downloading: {0} Bytes: {1}".format(url, file_size))

        file_size_dl = 0
        block_sz = 8192
        while True:
            buffer = u.read(block_sz)
            if not buffer:
                break

            file_size_dl += len(buffer)
            f.write(buffer)

            if verbose:
                status = "{0:16}".format(file_size_dl)
                if file_size:
                    status += "   [{0:6.2f}%]".format(file_size_dl * 100 / file_size)
                status += chr(13)
                print(status, end="")
        if verbose:
            print()

    return filename


import vmware_apix_client.apis
from vmware_apix_client.apis.apis_api import ApiClient

def create_apix_client(args):
    client = None

    if args.user:
        if not args.password:
            stderr("You must provide a password as well.")
            exit(1)
        vmware_apix_client.Configuration().username = args.user
        vmware_apix_client.Configuration().password = args.password

    if args.server:
        stdout("Disabling SSL certificate validation. (development use case)")
        # MUST have this argument for internal test servers or SSL verification will fail since they
        # have self signed certificates.
        vmware_apix_client.Configuration().verify_ssl = False
        urllib3.disable_warnings()

        hostUrl = args.server
        stdout("Connecting to server %s" % hostUrl)
        client = vmware_apix_client.ApiClient(host=hostUrl)
    else:
        client = vmware_apix_client.ApiClient()
    return client


def convert_markdown_file(markdown_file_path, output_html_file_path):
    markdownConvertor = markdown2.Markdown()
    stdout("    Converting and writing overview html '%s'" % (output_html_file_path))
    with open(markdown_file_path,"r") as input_file:
        markdown_content = input_file.read()
        with open(output_html_file_path, "w") as output_overview_file:

            #header_converted_content = re.sub(r'([#]+)', r'\1#', markdown_content)
            header_converted_content = markdown_content

            overviewHtml = markdownConvertor.convert(header_converted_content)

            output_overview_file.write(overviewHtml)


def _extract_first_sentence( input_text ):
    '''
    returns only the first sentence in its entirety provided that there is a period
    found.  If there is no period, the entire input text is returned.
    '''
    if not input_text:
        return input_text

    firstPeriodIndex = input_text.find('.')
    if firstPeriodIndex > 0:
        return input_text[:firstPeriodIndex + 1]
    else:
        return input_text

def _extract_what_is_section( input_markdown_text ):
    '''
    searches the input_markdown_text to see if it contains a section that starts with
    '# what is' case independent.  If it does, it skips to the end of that line, and extracts
    all text up to the next section or the first period, whichever comes first and returns
    that as plain text.  If this doesn't exist, None is returned.
    '''
    description_markdown = None
    input_markdown_text_lower = input_markdown_text.lower()
    whatIsIndex = input_markdown_text_lower.find('# what is')
    if whatIsIndex >= 0:
        firstEndOfLineIndex = input_markdown_text_lower.find('\n',whatIsIndex+2);
        nextSectionIndex = input_markdown_text_lower.find('#',whatIsIndex+2);

        if (firstEndOfLineIndex > whatIsIndex+2) and (nextSectionIndex > firstEndOfLineIndex):
            description_markdown = input_markdown_text[firstEndOfLineIndex:nextSectionIndex]

    return _extract_first_sentence(description_markdown)

def _extract_first_section_first_sentence( input_markdown_text ):
    description_markdown = None
    # next try to extract the sentence after the initial heading if it exists.
    initialHeadingIndex = input_markdown_text.find("#")
    if initialHeadingIndex >= 0:
        firstEndOfLineIndex = input_markdown_text.find('\n',initialHeadingIndex+1)
        if firstEndOfLineIndex > initialHeadingIndex+1:
            firstPeriodIndex = input_markdown_text.find('.',firstEndOfLineIndex+1)
            nextHashIndex = input_markdown_text.find('#',firstEndOfLineIndex+1)

            # use whatever end comes first, the first period or the next hash or the end of the string
            endIndex = len(input_markdown_text)
            if firstPeriodIndex >firstEndOfLineIndex+1:
                endIndex = firstPeriodIndex + 1
            if nextHashIndex > 0 and nextHashIndex < endIndex:
                endIndex = nextHashIndex
            description_markdown = input_markdown_text[firstEndOfLineIndex+1:endIndex]

    return description_markdown

def _extract_first_line( input_markdown_text ):
    description_markdown = None
    firstEndOfLineIndex = input_markdown_text.find('\n')
    if firstEndOfLineIndex > 0:
        description_markdown = input_markdown_text[firstEndOfLineIndex+1:]
    return description_markdown

def _strip_markdown_abbreviate( input_markdown, maxlen):
    if not input_markdown:
        return input_markdown
    markdownConvertor = markdown2.Markdown()
    html_description = markdownConvertor.convert(input_markdown)
    plain_text_description = abbrev_html(html_description,maxlen).strip()
    return plain_text_description

# def _extract_first_section_body( input_markdown_text ):
#
#     description_markdown = None
#
#     if isinstance(input_markdown_text, str):
#         full_md_lines = input_markdown_text.split('\n')
#     elif isinstance(input_markdown_text, unicode):
#         full_md_lines = input_markdown_text.split(u'\n')
#     else:
#         full_md_lines = None
#
#     if full_md_lines:
#         state = 0
#         for line in full_md_lines:
#             if line.startswith('#'):
#                 if not description_markdown:
#                     description_markdown = ""
#                 if state == 0:
#                     state = 1  # skip this line
#                 elif state == 1:
#                     break # we encountered another header in the section, we are done
#             else:
#                 description_markdown = description_markdown + line
#
#     return description_markdown

def abbreviate_markdown_text(full_input_markdown_description, abbreviate_description=False):
    '''
    takes input markdown as a string and returns a tuple of

    full_md_description,
    plain_text_description,
    abbrev_md_description
    '''
    #full_md_description = full_input_markdown_description.encode('UTF-8').strip()
    full_md_description = full_input_markdown_description.strip()
    plain_text_description = full_md_description
    abbrev_md_description = full_md_description

    if (abbreviate_description):

        if full_md_description.find("vRealize Orchestrator") > 0:
            stdout('found it')

        # first try to see if there is a what is section and use that content
        abbrev_md_description = _extract_what_is_section( full_md_description )

        # next try to get the description from the first sentence of the first section
        if not abbrev_md_description:
            abbrev_md_description = _extract_first_section_first_sentence( full_md_description )

        # next try to get the first line only
        if not abbrev_md_description:
            abbrev_md_description = _extract_first_line(full_md_description)

        if abbrev_md_description:
            abbrev_md_description = abbrev_md_description.strip()
            # strip the markdown
            plain_text_description = _strip_markdown_abbreviate(abbrev_md_description,256)
        else:
            abbrev_md_description = full_md_description

    # iterate through full_description downgrading all headers by adding a single #
    full_md_description = re.sub(r'([#]+)', r'\1#', full_md_description)

    return full_md_description, plain_text_description, abbrev_md_description


def load_properties_file(filepath, sep='=', comment_char='#', dict_to_fill=None):
    """
    Read the file passed as parameter as a properties file and return a dict of the values.
    """
    if dict_to_fill == None:
        dict_to_fill = {}
    with open(filepath, "rt") as f:
        for line in f:
            l = line.strip()
            if l and not l.startswith(comment_char):
                key_value = l.split(sep)
                key = key_value[0].strip()
                value = sep.join(key_value[1:]).strip().strip('"')
                dict_to_fill[key] = value
    return dict_to_fill
