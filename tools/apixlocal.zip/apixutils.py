"""
Copyright (c) 2016,  VMware Inc., All Rights Reserved.

This file is open source software released under the terms of the
BSD 3-Clause license, https://opensource.org/licenses/BSD-3-Clause:

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
 may be used to endorse or promote products derived from this software without
 specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

###############################################################################

This file is a utility meant for contributing samples to VMware Sample Exchange,
https://developercenter.vmware.com/samples
"""
from __future__ import ( division, absolute_import, print_function, unicode_literals )
import re
import urllib
import urllib3
import sys
#import base64
import glob
import os
import string
#import markdown2

from swagger_client.models.tag import Tag




#import sys, os, tempfile, logging

# TODO uncomment this when we move to python 3 support
#if sys.version_info >= (3,):
#    import urllib.request as urllib2
#    import urllib.parse as urlparse
#else:
import urllib2
import urlparse

#from swagger_client.models.category import Category


def stdout(lineString):
    sys.stdout.write(lineString)
    sys.stdout.write("\n")


def stderr(lineString):
    sys.stderr.write(lineString)
    sys.stderr.write("\n")

TAG_RE = re.compile(r'<[^>]+>')
WHITESPACE_RE = re.compile(r'[ \t\r\n]+')

def safe_str(obj):
    if obj:
        return str(obj)
    else:
        return "None"

def abbrev_readme(input_html):
    """
    remove all html from a description, consolidate whitespace, remove end of lines, and abbreviate at 100 chars.
    """
    if not input_html:
        return ""
    output = TAG_RE.sub('', input_html)
    output = WHITESPACE_RE.sub(' ', output)
    return (output[:100] + '..') if len(output) > 100 else output

tagCounter = 1

SLASH_RE = re.compile(r'[/ ]+')
CURLY_REMOVE_RE = re.compile(r'[{}]+')
SWAGGER_PATH_DASH_RE = re.compile(r'-')
SWAGGER_PATH_WS_RE = re.compile(r'[ \t]')
NOT_ALNUM_RE =  re.compile(r'[^A-Za-z0-9]+')

def swagger_path_to_operationId(httpMethod, swaggerOperationPath):
    '''
    create a swagger operation id from the method path such as /endpoints/types/extensions/{id}
    to get_endpoints_types_extensions_id
    '''
    if not swaggerOperationPath:
        return ""
    pathOperationId = swaggerOperationPath
    pathOperationId = CURLY_REMOVE_RE.sub('', pathOperationId)
    pathOperationId = SLASH_RE.sub('_', pathOperationId)

    return httpMethod + pathOperationId

def swagger_fix_operationId(operationId):
    '''
    make sure operation id is valid in case user messed it up
    '''
    if not operationId:
        return ""
    operationId = operationId.strip()
    operationId = NOT_ALNUM_RE.sub('_', operationId)
    return operationId

def swagger_make_method_url(tag, operationId):

    # I don't understand the pattern, but this is what swagger does, it puts the tag at the beginning of the method, and then
    # puts '45' for dashes and '32' for spaces, which appears to be the decimal for the ASCII char value, odd.  I guess this is their
    # own sort of URL encoding, albeit really stange.
    # TODO improve this algorithm to handle other characters as well.
    tagOperationId = SWAGGER_PATH_DASH_RE.sub('45', tag)
    tagOperationId = SWAGGER_PATH_WS_RE.sub('32', tagOperationId)

    # http://localhost:8082/swagger-console.html?url=local/swagger/api-vra-network-service.json&host=&basePath=#!/data45service/post_api_catalog_providers_providerId_requests_bindingId_complete
    url = "#!/" + tagOperationId + "/" + operationId
    return url


def appendTagsAndCategories(tags, categories, contribution):
    """
     Append any tags from the tags and categories lists to the given Contribution object
    :param tags: list of strings for tags.  can optionally have category and value separated by colon.
    :param categories: list of strings for category values.  Can optionally have type and version separated via colon.
    """
    global tagCounter
    # append any extra tags
    if tags:
        for tagString in tags:
            tagString = urllib.unquote(tagString).decode('utf8')

            newTag = Tag()
            newTag.id = tagCounter
            tagCounter = tagCounter + 1

            if not contribution.tags:
                contribution.tags = []

            colonIndex = tagString.find(':')
            if colonIndex != -1:
                category, tag = tagString.split(":")
                newTag.category = category
                newTag.name = tag
            else:
                newTag.category = "Tags"
                newTag.name = tagString

            # check that the tag is not already in the set
            alreadyIn = False
            for currentTag in contribution.tags:
                if (currentTag.name == newTag.name) and (currentTag.category == newTag.category):
                    alreadyIn = True

            if not alreadyIn:
                contribution.tags.append(newTag)

#      append any extra categories
#     if categories:
#         for value in categories:
#             value = urllib.unquote(value).decode('utf8')
#
#             newCategory = Category()
#             newCategory.id = tagCounter
#             tagCounter = tagCounter + 1
#
#             if not contribution.categories:
#                 contribution.categories = []
#
#             colonIndex = value.find(':')
#             if colonIndex != -1:
#                 catType, version = value.split(":")
#                 newCategory.type = catType
#                 newCategory.version = version
#             else:
#                 newCategory.version = ""
#                 newCategory.type = value
#
#              check that category is not already in the set
#             alreadyIn = False
#             for currentCategory in contribution.categories:
#                 if (currentCategory.type == newCategory.type) and (currentCategory.version == newCategory.version):
#                     alreadyIn = True
#
#             if not alreadyIn:
#                 contribution.categories.append(newCategory)

def fixSampleTitle(name):
    name = string.capwords(name)
    name = name.replace("Vmware", "VMware");
    name = name.replace("Vcenter", "vCenter");
    name = name.replace("VCenter", "vCenter");
    name = name.replace("Vsphere", "vSphere");
    name = name.replace("VSphere", "vSphere");

    name = name.replace("Vcloud", "vCloud");
    name = name.replace("VCloud", "vCloud");
    name = name.replace("Vsan", "vSAN");
    name = name.replace("Vapp", "vApp");
    name = name.replace("VApp", "vApp");
    name = name.replace("VMotion", "vMotion");
    name = name.replace("Vmotion", "vMotion");
    name = name.replace("Vco", "vCO");
    name = name.replace("Vra", "vRA");
    name = name.replace("Vro", "vRO");
    name = name.replace("VSan", "vSAN");
    name = name.replace("VSAN", "vSAN");
    name = name.replace("vSANVM", "vSAN VM");
    name = name.replace("VApp", "vApp");
    name = name.replace("Esxi", "ESXi");
    name = name.replace("Vmdk", "VMDK");
    name = name.replace("Nsx", "NSX");
    name = name.replace("Vaai", "VAAI");
    name = name.replace("Vm ", "VM ");
    name = name.replace(" Vm", " VM");
    name = name.replace("VSphereAutoRestartManager", "vSphere Auto Restart Manager");
    name = name.replace("Getorphanedvms", "Get Orphaned VMs");
    name = name.replace("Getallvms", "Get All VMs");
    name = name.replace("Uuid", "UUID");
    name = name.replace(" Dc", " DC");
    name = name.replace("Ovf", "OVF");

    name = name.replace("Scsi", "SCSI");
    name = name.replace("Sata", "SATA");
    name = name.replace("Iso", "ISO");
    name = name.replace("Cpu", "CPU");
    name = name.replace("Crud", "CRUD");

    name = name.replace("Cls", "CLS");
    name = name.replace("Api", "API");
    name = name.replace("Sdk", "SDK");
    name = name.replace("Psc", "PSC");
    name = name.replace("Sso", "SSO");
    name = name.replace("Create Create", "Create");

    return name



def findFiles(directoryPath, globPattern, recursive, filePathList, verbose):
    '''
    For a given directory and glob pattern, scan for files that match the glob and
    append the full paths to the file to the filePathList.

    directoryPath: string path to scan in

    globPattern: string glob to search for, e.g. "*.java"

    recursive: if True, then we recurse into subdirectories looking for the files as well

    filePathList: output param, string list to append full paths to

    verbose: if True print the names of directories to stdout as we enter them
    '''
    for dirpath, dirnames, filenames in os.walk(directoryPath):
        if verbose:
            stdout("Scanning dir %s" % dirpath)
        # os.chdir(dirpath)
        globMatchingFiles = glob.glob1(dirpath, globPattern)
        for f in globMatchingFiles:
            filePathList.append(os.path.join(dirpath, f))
        if not recursive:
            while len(dirnames) > 0:
                dirnames.pop()
        #directoriesScanned.append(dirpath)

def extract_markdown_relative_links(markdown_text):
    '''
    Returns a list of strings that are relative hyper links
    found in the given text.  No checking as to whether or not the
    content is really markdown, only whether or not it has valid markdown links.
    '''
    link_list = []

    # markdown links are of the format [<optional text>](link)
    pattern = re.compile(r'!\[([^\]]*)\][ \t]*\(([^\)]+)\)')

    for (title, url) in re.findall(pattern, markdown_text):
        #stdout("title='" + title + "' value='" + url + "'")
        link_list.append(url)

    return link_list


def download_file(url, dir=None, verbose=None):
    '''
    Download a file from the given URL.
    dir: optional path to place the file in
    '''
    u = urllib2.urlopen(url)

    scheme, netloc, path, query, fragment = urlparse.urlsplit(url)
    filename = os.path.basename(path)
    if not filename:
        filename = 'downloaded.file'
    if dir:
        filename = os.path.join(dir, filename)

    with open(filename, 'wb') as f:
        meta = u.info()
        meta_func = meta.getheaders if hasattr(meta, 'getheaders') else meta.get_all
        meta_length = meta_func("Content-Length")
        file_size = None
        if meta_length:
            file_size = int(meta_length[0])
        print("    Downloading: {0} Bytes: {1}".format(url, file_size))

        file_size_dl = 0
        block_sz = 8192
        while True:
            buffer = u.read(block_sz)
            if not buffer:
                break

            file_size_dl += len(buffer)
            f.write(buffer)

            if verbose:
                status = "{0:16}".format(file_size_dl)
                if file_size:
                    status += "   [{0:6.2f}%]".format(file_size_dl * 100 / file_size)
                status += chr(13)
                print(status, end="")
        if verbose:
            print()

    return filename


import swagger_client.apis
from swagger_client.apis.apis_api import ApiClient

def create_apix_client(args):
    client = None

    if args.user:
        if not args.password:
            stderr("You must provide a password as well.")
            exit(1)
        swagger_client.Configuration().username = args.user
        swagger_client.Configuration().password = args.password

    if args.server:
        stdout("Disabling SSL certificate validation. (development use case)")
        # MUST have this argument for internal test servers or SSL verification will fail since they
        # have self signed certificates.
        swagger_client.Configuration().verify_ssl = False
        urllib3.disable_warnings()

        hostUrl = args.server
        stdout("Connecting to server %s" % hostUrl)
        client = swagger_client.ApiClient(host=hostUrl)
    else:
        client = swagger_client.ApiClient()
    return client
