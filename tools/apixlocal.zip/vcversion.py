"""

"""
from __future__ import print_function
import json
import sys


def write_json_data_to_file(file_name, json_data):
    """
    Utility method used to write json file.
    """
    with open(file_name, 'w+') as outfile:
        json.dump(json_data, outfile, indent=4)

def get_product_version_and_build(update_conf_file_path):
    '''
    read data from /etc/applmgmt/appliance/update.conf, which is a json
    file and extracts the product, version, and build info.
    Returns a string tuple with the product, version, and build
    '''
    product = None
    version = None
    build = None
    with open(update_conf_file_path,'r') as update_conf_file:
        json_data = json.load(update_conf_file)
        product = json_data['product']
        version = json_data['version']
        build = json_data['build']
    return product,version,build

def get_code_client_string(product, version, build):
    '''
    read data from /etc/applmgmt/appliance/update.conf, which is a json
    file and extracts the product, version, and build info for use as the client id
    in API Explorer.  A string is returned of the format
    "apix,<product>,<version>,<build>" which is the expected format.
    '''
    code_client = 'apix,VMware vCenter Server Appliance'
    if product:
        code_client = 'apix,' + product
    if version:
        code_client = code_client + ',' + version
    if build:
        code_client = code_client + ',' + build

    return code_client

def replace_client_id_in_apix_config_json(product, version, build, apix_config_file_path):

    # make a client id for the API explorer using data in /etc/applmgmt/appliance/update.conf
    new_code_client_id =  get_code_client_string(product, version, build)

    apix_config_json_data = None

    # open the apix-config.json file in read mode and scan in the json
    with open(apix_config_file_path,'r') as apix_config_file:
        apix_config_json_data = json.load(apix_config_file)

    if not apix_config_json_data:
        print("Unable to read existing configuration data from " + apix_config_file_path + "\n")
        return

    existing_code_client_id = apix_config_json_data['vmwareCodeClient']
    if existing_code_client_id != new_code_client_id:
        # the client id value has changed, update the value with the new client id and write the file out.
        apix_config_json_data['vmwareCodeClient'] = new_code_client_id
        print("Updating vmwareCodeClient value to '%s' in %s" % (new_code_client_id, apix_config_file_path))
        write_json_data_to_file(apix_config_file_path, apix_config_json_data)


def main(argv):

    update_conf_file_path = argv[0]
    apix_config_file_path = argv[1]


    # get the product and version info for the current running appliance version
    product, version, build = get_product_version_and_build(update_conf_file_path)

    print(get_code_client_string(product, version, build))

    # create a client id using the product, version and build and update in the apix-config file
    replace_client_id_in_apix_config_json(product, version, build, apix_config_file_path)

    # version is 4 digit, we only want to include 3 in the presentation, so split the last off
    three_digit_version = version[:version.rfind('.')]
    print("three_digit_version=" + three_digit_version)


if __name__ == "__main__":
    main(sys.argv[1:])
